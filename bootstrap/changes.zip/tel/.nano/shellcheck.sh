#!/bin/sh -ev
# Shellcheck the script

shellcheck install.sh
