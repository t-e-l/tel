#!/usr/bin/env bash
tmux new-window -n 'Tutorial' ~/.tel/scripts/tutorial.sh
exit 0
